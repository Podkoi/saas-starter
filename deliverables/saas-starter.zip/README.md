Local dev

If you want to test the demo checkout flow locally the project includes a mock serverless handler at `api/checkout.js` which responds with a placeholder URL.

Environment variables

- `VITE_STRIPE_PUBLISHABLE_KEY`: Your Stripe publishable key (used in frontend when integrating Stripe.js)
- `ANALYTICS_ID`: Analytics identifier (GA4/UA/Plausible)
- `STRIPE_SECRET_KEY`: Your Stripe secret key for server-side session creation (optional for local mock)
- `STRIPE_PRO_PRICE_ID`: The Stripe Price ID for the Pro subscription plan
- `STRIPE_CUSTOMER_ID`: (optional) Stripe customer ID for billing portal access
- `STRIPE_WEBHOOK_SECRET`: The webhook signing secret for validating Stripe webhooks (optional)

Stripe setup (quick)

1. Create a Stripe account and get your Publishable and Secret keys.
2. Create a recurring price in Stripe and set `STRIPE_PRO_PRICE_ID`.
3. Set `VITE_STRIPE_PUBLISHABLE_KEY`, `STRIPE_SECRET_KEY`, and `STRIPE_PRO_PRICE_ID` in your hosting env (Vercel/Netlify).
4. Use `/api/subscriptions` for subscription checkout and `/api/portal` for the customer portal.
5. Configure webhook endpoint `/api/webhook` in Stripe dashboard and set `STRIPE_WEBHOOK_SECRET`.

Theme & customization

- Use the Theme switcher in the top-right to preview themes. To persist themes or add more, extend `ThemeSwitcher.jsx` and wire to localStorage or a user setting.


# SaaS Starter — Landing + Dashboard Template

This is a minimal, sellable starter template: landing page, demo dashboard, Tailwind styles, and deployment-ready config (Vite + Tailwind).

Quick start

```bash
npm install
npm run dev
```

Deploy: push to Vercel or Netlify; build command is `npm run build`.

GitHub Pages

This repo includes a GitHub Actions workflow that builds the site and deploys the `dist` directory to the `gh-pages` branch on push to `main`.

To enable Pages:

1. In your repository settings, under "Pages", set the source to the `gh-pages` branch (root).
2. Push to `main` — the `pages.yml` workflow will build and publish automatically.

Packaging with custom domain

When creating the deliverable zip, you can include a `CNAME` so the package contains the custom domain. Set the env var `PAGES_CUSTOM_DOMAIN` when running the package script. Examples:

Unix/macOS:

```bash
PAGES_CUSTOM_DOMAIN=example.com node scripts/package.js
```

Windows (PowerShell):

```powershell
$env:PAGES_CUSTOM_DOMAIN = 'example.com'; node scripts/package.js
```

What's included

- Landing: hero, features, pricing
- Dashboard: demo metrics and CMS placeholder
- Tailwind CSS
- Vite dev server

Next steps (recommended)

- Add Stripe integration and serverless checkout (see `api/stripe-placeholder.js`)
- Hook up a headless CMS or simple JSON-based content API
- Add SEO and analytics keys in environment variables (replace analytics placeholder in `index.html`)

Deployment (Vercel)

1. Push this repo to GitHub.
2. Import project in Vercel and set build command `npm run build` and output directory `dist`.
3. Add environment variables for Stripe and analytics.

Deployment (Netlify)

1. Push this repo to GitHub.
2. Add site in Netlify and set the build command to `npm run build`.
3. Set the publish directory to `dist`.
4. Add environment variables for Stripe and analytics.

Deployment (GitHub Pages)

1. Enable Pages source on the `gh-pages` branch.
2. The `.github/workflows/pages.yml` workflow builds and deploys on push to `main`.
3. Set `PAGES_CUSTOM_DOMAIN` secret if you want a custom domain.

Marketing pitch (short)

Sell a polished starter to early-stage founders: "Ship a branded landing, checkout, and admin dashboard in days — Stripe-ready, customizable, and deployable to Vercel."

