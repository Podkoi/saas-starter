Local dev

If you want to test the demo checkout flow locally the project includes a mock serverless handler at `api/checkout.js` which responds with a placeholder URL.

Environment variables

- `VITE_STRIPE_PUBLISHABLE_KEY`: Your Stripe publishable key (used in frontend when integrating Stripe.js)
- `ANALYTICS_ID`: Analytics identifier (GA4/UA/Plausible)
 - `STRIPE_SECRET_KEY`: Your Stripe secret key for server-side session creation (optional for local mock)

# SaaS Starter — Landing + Dashboard Template

This is a minimal, sellable starter template: landing page, demo dashboard, Tailwind styles, and deployment-ready config (Vite + Tailwind).

Quick start

```bash
npm install
npm run dev
```

Deploy: push to Vercel or Netlify; build command is `npm run build`.

What's included

- Landing: hero, features, pricing
- Dashboard: demo metrics and CMS placeholder
- Tailwind CSS
- Vite dev server

Next steps (recommended)

- Add Stripe integration and serverless checkout (see `api/stripe-placeholder.js`)
- Hook up a headless CMS or simple JSON-based content API
- Add SEO and analytics keys in environment variables (replace analytics placeholder in `index.html`)

Deployment (Vercel)

1. Push this repo to GitHub.
2. Import project in Vercel and set build command `npm run build` and output directory `dist`.
3. Add environment variables for any API keys (Stripe, analytics).

Marketing pitch (short)

Sell a polished starter to early-stage founders: "Ship a branded landing, checkout, and admin dashboard in days — Stripe-ready, customizable, and deployable to Vercel."

